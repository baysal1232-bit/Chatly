package com.example.model

/**
 * Chatly User representation.
 * Each user has a unique Chatly ID prefixed with '@' (e.g., @chatly123).
 */
data class ChatlyUser(
  val id: String,
  val chatlyId: String, // e.g. "@gokhan123"
  val displayName: String,
  val photoUrl: String? = null,
  val statusMessage: String = "Chatly kullanıyor",
  val isOnline: Boolean = false,
  val lastSeenTimestamp: Long = System.currentTimeMillis(),
  val isVerified: Boolean = false,
  val isPremium: Boolean = false,
)
