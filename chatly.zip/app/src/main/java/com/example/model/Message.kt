package com.example.model

enum class MessageType {
  TEXT,
  IMAGE,
  VIDEO,
  AUDIO,
  FILE,
  LOCATION,
  CONTACT,
}

enum class MessageDeliveryStatus {
  SENDING,
  SENT,
  DELIVERED,
  READ,
}

/**
 * Chatly Message model supporting real-time messaging, media types,
 * delivery indicators, replies, reactions, and disappearing timers.
 */
data class ChatlyMessage(
  val id: String,
  val chatId: String,
  val senderId: String,
  val senderChatlyId: String,
  val content: String,
  val type: MessageType = MessageType.TEXT,
  val deliveryStatus: MessageDeliveryStatus = MessageDeliveryStatus.SENT,
  val timestamp: Long = System.currentTimeMillis(),
  val replyToId: String? = null,
  val replyToSnippet: String? = null,
  val reactions: Map<String, String> = emptyMap(), // userId -> emoji
  val isPinned: Boolean = false,
  val isEdited: Boolean = false,
  val isDeleted: Boolean = false,
  val mediaUrl: String? = null,
  val fileName: String? = null,
  val fileSize: String? = null,
  val durationSeconds: Int? = null,
  val disappearingExpiresAt: Long? = null, // Server timestamp when auto-deleted
)
