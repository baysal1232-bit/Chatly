package com.example.model

/**
 * Chatly Community structure.
 */
data class ChatlyCommunity(
  val id: String,
  val name: String,
  val description: String,
  val photoUrl: String? = null,
  val membersCount: Int = 0,
  val announcementChannelId: String = "",
  val announcementChannelName: String = "Duyurular",
  val subGroupsCount: Int = 0,
  val isOwner: Boolean = false,
)
