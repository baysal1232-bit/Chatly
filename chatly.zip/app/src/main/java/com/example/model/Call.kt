package com.example.model

enum class CallType {
  AUDIO,
  VIDEO,
}

enum class CallDirection {
  INCOMING,
  OUTGOING,
  MISSED,
}

/**
 * Chatly Call log entry.
 */
data class ChatlyCall(
  val id: String,
  val peerId: String,
  val peerDisplayName: String,
  val peerChatlyId: String,
  val peerPhotoUrl: String? = null,
  val callType: CallType = CallType.AUDIO,
  val direction: CallDirection = CallDirection.INCOMING,
  val timestamp: Long = System.currentTimeMillis(),
  val durationSeconds: Int = 0,
  val isGroupCall: Boolean = false,
)
