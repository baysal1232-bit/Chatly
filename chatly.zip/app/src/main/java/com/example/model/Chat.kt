package com.example.model

enum class ChatType {
  DIRECT,
  GROUP,
}

/**
 * Summary for a conversation in Chatly's main inbox.
 */
data class ChatSummary(
  val id: String,
  val type: ChatType,
  val title: String,
  val chatlyId: String? = null, // "@username" for direct chats
  val photoUrl: String? = null,
  val lastMessage: ChatlyMessage? = null,
  val unreadCount: Int = 0,
  val isPinned: Boolean = false,
  val isMuted: Boolean = false,
  val isArchived: Boolean = false,
  val isSecret: Boolean = false,
  val isOnline: Boolean = false,
  val isTyping: Boolean = false,
  val disappearingDurationSeconds: Long = 0L, // 0 = disabled
)
