package com.example.model

enum class StatusMediaType {
  TEXT,
  IMAGE,
  VIDEO,
  MUSIC,
}

enum class StatusPrivacy {
  EVERYONE,
  MY_CONTACTS,
  EXCEPT,
  ONLY_SELECTED,
}

/**
 * Chatly Status — Exactly 36 Hours Active.
 * createdAt = server timestamp
 * expiresAt = createdAt + 36 hours (129,600,000 ms)
 */
data class ChatlyStatus(
  val id: String,
  val userId: String,
  val chatlyId: String,
  val userDisplayName: String,
  val userPhotoUrl: String? = null,
  val mediaType: StatusMediaType = StatusMediaType.TEXT,
  val textContent: String = "",
  val mediaUrl: String? = null,
  val caption: String = "",
  val backgroundColorHex: Long = 0xFF4F46E5,
  val musicTitle: String? = null,
  val createdAt: Long = System.currentTimeMillis(),
  val expiresAt: Long = createdAt + STATUS_DURATION_MS,
  val privacy: StatusPrivacy = StatusPrivacy.MY_CONTACTS,
  val viewCount: Int = 0,
  val isViewedByMe: Boolean = false,
  val isMyStatus: Boolean = false,
) {
  companion object {
    /** Exact 36-hour duration in milliseconds: 36 * 60 * 60 * 1000 */
    const val STATUS_DURATION_MS: Long = 36L * 60L * 60L * 1000L

    /**
     * Calculates remaining hours and minutes until status expiration.
     */
    fun getRemainingTimeFormatted(expiresAt: Long, currentTime: Long = System.currentTimeMillis()): String {
      val diffMs = expiresAt - currentTime
      if (diffMs <= 0) return "Süresi doldu"
      val totalHours = diffMs / (1000 * 60 * 60)
      val totalMinutes = (diffMs % (1000 * 60 * 60)) / (1000 * 60)
      return "${totalHours}s ${totalMinutes}d kaldı (36s)"
    }
  }

  val isExpired: Boolean
    get() = System.currentTimeMillis() >= expiresAt
}
