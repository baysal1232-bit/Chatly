package com.example.data

import com.example.model.ChatlyStatus
import kotlinx.coroutines.flow.Flow

/**
 * Contract for Chatly Status — Exactly 36 Hours Active.
 * Automatic server-side expiry & client filtration after 36 hours.
 */
interface StatusRepository {
  fun getActiveStatuses(): Flow<List<ChatlyStatus>>
  fun getMyStatuses(): Flow<List<ChatlyStatus>>
  suspend fun publishStatus(status: ChatlyStatus): Result<Unit>
  suspend fun recordStatusView(statusId: String): Result<Unit>
  suspend fun reactToStatus(statusId: String, emoji: String): Result<Unit>
  suspend fun deleteStatus(statusId: String): Result<Unit>
}
