package com.example.data

import com.example.model.ChatSummary
import com.example.model.ChatlyMessage
import kotlinx.coroutines.flow.Flow

/**
 * Contract for real-time messaging, direct/group chats, reactions,
 * disappearing messages, search, pinning, and muting.
 */
interface ChatRepository {
  fun getChats(): Flow<List<ChatSummary>>
  fun getMessages(chatId: String): Flow<List<ChatlyMessage>>
  suspend fun sendMessage(chatId: String, message: ChatlyMessage): Result<Unit>
  suspend fun markAsRead(chatId: String, messageId: String): Result<Unit>
  suspend fun setTyping(chatId: String, isTyping: Boolean): Result<Unit>
  suspend fun addReaction(chatId: String, messageId: String, emoji: String): Result<Unit>
  suspend fun editMessage(chatId: String, messageId: String, newContent: String): Result<Unit>
  suspend fun deleteMessage(chatId: String, messageId: String, forEveryone: Boolean): Result<Unit>
  suspend fun togglePinChat(chatId: String, isPinned: Boolean): Result<Unit>
  suspend fun toggleMuteChat(chatId: String, isMuted: Boolean): Result<Unit>
  suspend fun createGroup(title: String, participantIds: List<String>, description: String?): Result<String>
}
