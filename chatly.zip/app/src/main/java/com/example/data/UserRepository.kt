package com.example.data

import com.example.model.ChatlyUser
import kotlinx.coroutines.flow.Flow

/**
 * Contract for Chatly user profiles, unique Chatly ID resolution,
 * user search (@username), friendships, and blocking/reporting.
 */
interface UserRepository {
  fun getCurrentUser(): Flow<ChatlyUser?>
  suspend fun getUserByChatlyId(chatlyId: String): ChatlyUser?
  suspend fun searchUsers(query: String): List<ChatlyUser>
  suspend fun sendFriendRequest(targetUserId: String): Result<Unit>
  suspend fun acceptFriendRequest(requestId: String): Result<Unit>
  suspend fun removeFriend(userId: String): Result<Unit>
  suspend fun blockUser(userId: String): Result<Unit>
  suspend fun unblockUser(userId: String): Result<Unit>
  suspend fun reportUser(userId: String, reason: String): Result<Unit>
  suspend fun updateProfile(displayName: String, statusMessage: String, photoUrl: String?): Result<Unit>
}
