package com.example.data

import com.example.model.CallDirection
import com.example.model.CallType
import com.example.model.ChatSummary
import com.example.model.ChatType
import com.example.model.ChatlyCall
import com.example.model.ChatlyMessage
import com.example.model.ChatlyStatus
import com.example.model.ChatlyUser
import com.example.model.MessageDeliveryStatus
import com.example.model.MessageType
import com.example.model.StatusMediaType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Standard in-memory reactive repository provider for Chatly.
 * Ready for drop-in Firebase Firestore/Auth repository swap.
 */
class DefaultChatlyRepository private constructor() :
  UserRepository,
  ChatRepository,
  StatusRepository,
  CallRepository {

  companion object {
    val instance: DefaultChatlyRepository by lazy { DefaultChatlyRepository() }
  }

  private val _currentUser = MutableStateFlow<ChatlyUser?>(
    ChatlyUser(
      id = "user_me",
      chatlyId = "@chatly_user",
      displayName = "Chatly Kullanıcısı",
      statusMessage = "Chatly ile bağlantıda!",
      isOnline = true,
      isVerified = true,
    )
  )

  private val _chats = MutableStateFlow<List<ChatSummary>>(emptyList())
  private val _messages = MutableStateFlow<Map<String, List<ChatlyMessage>>>(emptyMap())
  private val _statuses = MutableStateFlow<List<ChatlyStatus>>(emptyList())
  private val _calls = MutableStateFlow<List<ChatlyCall>>(emptyList())

  // UserRepository
  override fun getCurrentUser(): Flow<ChatlyUser?> = _currentUser.asStateFlow()

  override suspend fun getUserByChatlyId(chatlyId: String): ChatlyUser? {
    val normalized = if (chatlyId.startsWith("@")) chatlyId else "@$chatlyId"
    return if (_currentUser.value?.chatlyId.equals(normalized, ignoreCase = true)) {
      _currentUser.value
    } else null
  }

  override suspend fun searchUsers(query: String): List<ChatlyUser> {
    if (query.isBlank()) return emptyList()
    val clean = query.trim().removePrefix("@").lowercase()
    val me = _currentUser.value ?: return emptyList()
    return if (me.chatlyId.removePrefix("@").lowercase().contains(clean) ||
      me.displayName.lowercase().contains(clean)
    ) {
      listOf(me)
    } else {
      emptyList()
    }
  }

  override suspend fun sendFriendRequest(targetUserId: String): Result<Unit> = Result.success(Unit)
  override suspend fun acceptFriendRequest(requestId: String): Result<Unit> = Result.success(Unit)
  override suspend fun removeFriend(userId: String): Result<Unit> = Result.success(Unit)
  override suspend fun blockUser(userId: String): Result<Unit> = Result.success(Unit)
  override suspend fun unblockUser(userId: String): Result<Unit> = Result.success(Unit)
  override suspend fun reportUser(userId: String, reason: String): Result<Unit> = Result.success(Unit)

  override suspend fun updateProfile(
    displayName: String,
    statusMessage: String,
    photoUrl: String?
  ): Result<Unit> {
    _currentUser.update { current ->
      current?.copy(
        displayName = displayName,
        statusMessage = statusMessage,
        photoUrl = photoUrl ?: current.photoUrl
      )
    }
    return Result.success(Unit)
  }

  // ChatRepository
  override fun getChats(): Flow<List<ChatSummary>> = _chats.asStateFlow()

  override fun getMessages(chatId: String): Flow<List<ChatlyMessage>> {
    val flow = MutableStateFlow(_messages.value[chatId] ?: emptyList())
    return flow.asStateFlow()
  }

  override suspend fun sendMessage(chatId: String, message: ChatlyMessage): Result<Unit> {
    _messages.update { current ->
      val list = current[chatId].orEmpty() + message
      current + (chatId to list)
    }
    _chats.update { list ->
      list.map { chat ->
        if (chat.id == chatId) chat.copy(lastMessage = message) else chat
      }
    }
    return Result.success(Unit)
  }

  override suspend fun markAsRead(chatId: String, messageId: String): Result<Unit> = Result.success(Unit)
  override suspend fun setTyping(chatId: String, isTyping: Boolean): Result<Unit> = Result.success(Unit)
  override suspend fun addReaction(chatId: String, messageId: String, emoji: String): Result<Unit> = Result.success(Unit)
  override suspend fun editMessage(chatId: String, messageId: String, newContent: String): Result<Unit> = Result.success(Unit)
  override suspend fun deleteMessage(chatId: String, messageId: String, forEveryone: Boolean): Result<Unit> = Result.success(Unit)
  override suspend fun togglePinChat(chatId: String, isPinned: Boolean): Result<Unit> = Result.success(Unit)
  override suspend fun toggleMuteChat(chatId: String, isMuted: Boolean): Result<Unit> = Result.success(Unit)
  override suspend fun createGroup(
    title: String,
    participantIds: List<String>,
    description: String?
  ): Result<String> {
    val newId = "group_${System.currentTimeMillis()}"
    val newChat = ChatSummary(
      id = newId,
      type = ChatType.GROUP,
      title = title,
    )
    _chats.update { listOf(newChat) + it }
    return Result.success(newId)
  }

  // StatusRepository (36 hours strict enforcement)
  override fun getActiveStatuses(): Flow<List<ChatlyStatus>> {
    val now = System.currentTimeMillis()
    // Clean expired statuses (> 36 hours)
    val active = _statuses.value.filter { !it.isExpired && !it.isMyStatus }
    return MutableStateFlow(active).asStateFlow()
  }

  override fun getMyStatuses(): Flow<List<ChatlyStatus>> {
    val myActive = _statuses.value.filter { it.isMyStatus && !it.isExpired }
    return MutableStateFlow(myActive).asStateFlow()
  }

  override suspend fun publishStatus(status: ChatlyStatus): Result<Unit> {
    val now = System.currentTimeMillis()
    val validStatus = status.copy(
      createdAt = now,
      expiresAt = now + ChatlyStatus.STATUS_DURATION_MS
    )
    _statuses.update { listOf(validStatus) + it }
    return Result.success(Unit)
  }

  override suspend fun recordStatusView(statusId: String): Result<Unit> = Result.success(Unit)
  override suspend fun reactToStatus(statusId: String, emoji: String): Result<Unit> = Result.success(Unit)
  override suspend fun deleteStatus(statusId: String): Result<Unit> {
    _statuses.update { list -> list.filterNot { it.id == statusId } }
    return Result.success(Unit)
  }

  // CallRepository
  override fun getCallLogs(): Flow<List<ChatlyCall>> = _calls.asStateFlow()
  override suspend fun initiateCall(targetUserId: String, isVideo: Boolean): Result<String> =
    Result.success("call_${System.currentTimeMillis()}")
  override suspend fun answerCall(callId: String): Result<Unit> = Result.success(Unit)
  override suspend fun endCall(callId: String): Result<Unit> = Result.success(Unit)
  override suspend fun clearCallLogs(): Result<Unit> {
    _calls.value = emptyList()
    return Result.success(Unit)
  }
}
