package com.example.data

import com.example.model.ChatlyUser
import kotlinx.coroutines.flow.Flow

sealed class AuthState {
  data object Initial : AuthState()
  data object Loading : AuthState()
  data class Authenticated(val user: ChatlyUser) : AuthState()
  data object Unauthenticated : AuthState()
  data class Error(val message: String) : AuthState()
}

/**
 * Authentication contract for Google Sign-In and Chatly ID registration.
 */
interface AuthRepository {
  val authState: Flow<AuthState>
  suspend fun signInWithGoogle(idToken: String): Result<ChatlyUser>
  suspend fun registerChatlyId(desiredChatlyId: String, displayName: String): Result<ChatlyUser>
  suspend fun signOut(): Result<Unit>
  suspend fun deleteAccount(): Result<Unit>
}
