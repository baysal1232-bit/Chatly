package com.example.data

import com.example.model.ChatlyCall
import kotlinx.coroutines.flow.Flow

/**
 * Contract for Call logging and WebRTC voice/video connection signaling.
 */
interface CallRepository {
  fun getCallLogs(): Flow<List<ChatlyCall>>
  suspend fun initiateCall(targetUserId: String, isVideo: Boolean): Result<String>
  suspend fun answerCall(callId: String): Result<Unit>
  suspend fun endCall(callId: String): Result<Unit>
  suspend fun clearCallLogs(): Result<Unit>
}
