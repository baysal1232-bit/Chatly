package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ChatlyIndigoDark,
    onPrimary = Color.Black,
    primaryContainer = ChatlyIndigoContainerDark,
    onPrimaryContainer = ChatlyIndigoContainerLight,
    secondary = ChatlyCyanDark,
    onSecondary = Color.Black,
    secondaryContainer = ChatlyCyanContainerDark,
    onSecondaryContainer = ChatlyCyanContainerLight,
    tertiary = ChatlyCoralDark,
    background = ChatlyDarkBackground,
    surface = ChatlyDarkSurface,
    surfaceVariant = ChatlyDarkSurfaceVariant,
    onBackground = ChatlyDarkOnSurface,
    onSurface = ChatlyDarkOnSurface,
    onSurfaceVariant = ChatlyDarkOnSurfaceVariant,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = ChatlyIndigoPrimary,
    onPrimary = Color.White,
    primaryContainer = ChatlyIndigoContainerLight,
    onPrimaryContainer = ChatlyIndigoContainerDark,
    secondary = ChatlyCyanSecondary,
    onSecondary = Color.White,
    secondaryContainer = ChatlyCyanContainerLight,
    onSecondaryContainer = ChatlyCyanContainerDark,
    tertiary = ChatlyCoralTertiary,
    background = ChatlyLightBackground,
    surface = ChatlyLightSurface,
    surfaceVariant = ChatlyLightSurfaceVariant,
    onBackground = ChatlyLightOnSurface,
    onSurface = ChatlyLightOnSurface,
    onSurfaceVariant = ChatlyLightOnSurfaceVariant,
  )

@Composable
fun ChatlyTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use Chatly brand identity by default
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  ChatlyTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

