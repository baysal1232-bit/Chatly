package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chatly Brand Palette (Electric Indigo, Vivid Cyan, Slate)
val ChatlyIndigoPrimary = Color(0xFF4F46E5)
val ChatlyIndigoDark = Color(0xFF818CF8)
val ChatlyIndigoContainerLight = Color(0xFFE0E7FF)
val ChatlyIndigoContainerDark = Color(0xFF312E81)

val ChatlyCyanSecondary = Color(0xFF0891B2)
val ChatlyCyanDark = Color(0xFF22D3EE)
val ChatlyCyanContainerLight = Color(0xFFCFFAFE)
val ChatlyCyanContainerDark = Color(0xFF164E63)

val ChatlyCoralTertiary = Color(0xFFF43F5E)
val ChatlyCoralDark = Color(0xFFFB7185)

val ChatlyStatusRing36h = Color(0xFF06B6D4)
val ChatlyStatusRingGradientStart = Color(0xFF6366F1)
val ChatlyStatusRingGradientEnd = Color(0xFF06B6D4)

// Neutral Colors
val ChatlyLightBackground = Color(0xFFF8FAFC)
val ChatlyLightSurface = Color(0xFFFFFFFF)
val ChatlyLightSurfaceVariant = Color(0xFFF1F5F9)
val ChatlyLightOnSurface = Color(0xFF0F172A)
val ChatlyLightOnSurfaceVariant = Color(0xFF475569)

val ChatlyDarkBackground = Color(0xFF0B0F19)
val ChatlyDarkSurface = Color(0xFF111827)
val ChatlyDarkSurfaceVariant = Color(0xFF1F2937)
val ChatlyDarkOnSurface = Color(0xFFF9FAFB)
val ChatlyDarkOnSurfaceVariant = Color(0xFF9CA3AF)

// Status & Indicators
val ChatlyOnlineGreen = Color(0xFF10B981)
val ChatlyUnreadBadge = Color(0xFF4F46E5)

// Legacy aliases for existing template preview compatibility
val Purple80 = ChatlyIndigoDark
val PurpleGrey80 = ChatlyCyanDark
val Pink80 = ChatlyCoralDark
val Purple40 = ChatlyIndigoPrimary
val PurpleGrey40 = ChatlyCyanSecondary
val Pink40 = ChatlyCoralTertiary

