package com.example.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ChatlyUser

@Composable
fun SearchUserDialog(
  onDismiss: () -> Unit,
  onUserSelected: (ChatlyUser) -> Unit,
  modifier: Modifier = Modifier,
) {
  var searchQuery by remember { mutableStateOf("") }
  var searchedUser by remember { mutableStateOf<ChatlyUser?>(null) }
  var hasSearched by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = modifier
        .fillMaxWidth()
        .testTag("search_user_dialog"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface
      )
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Kullanıcı Bul",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat")
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Arkadaşınızın @chatly_id adresini yazarak arayın:",
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = searchQuery,
          onValueChange = {
            searchQuery = it
            hasSearched = false
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("chatly_id_search_input"),
          placeholder = { Text("@kullaniciadi") },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            hasSearched = true
            val query = searchQuery.trim()
            if (query.isNotBlank()) {
              val cleanId = if (query.startsWith("@")) query else "@$query"
              searchedUser = ChatlyUser(
                id = "user_${cleanId.removePrefix("@")}",
                chatlyId = cleanId,
                displayName = cleanId.removePrefix("@").replaceFirstChar { it.uppercase() },
                statusMessage = "Chatly kullanıyor",
                isOnline = true
              )
            } else {
              searchedUser = null
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_action_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary
          )
        ) {
          Text("Ara", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (hasSearched) {
          searchedUser?.let { user ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = user.displayName.take(1),
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = user.displayName,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = user.chatlyId,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
              IconButton(onClick = { onUserSelected(user) }) {
                Icon(
                  imageVector = Icons.Default.PersonAdd,
                  contentDescription = "Arkadaş Ekle",
                  tint = MaterialTheme.colorScheme.primary
                )
              }
            }
          } ?: run {
            Text(
              text = "Kullanıcı bulunamadı. Lütfen Chatly ID'yi kontrol edin.",
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(vertical = 8.dp)
            )
          }
        }
      }
    }
  }
}
