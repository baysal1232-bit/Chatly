package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import com.example.data.DefaultChatlyRepository
import com.example.model.ChatSummary
import com.example.model.ChatType
import com.example.model.ChatlyUser
import com.example.ui.components.ChatlyBottomBar
import com.example.ui.components.ChatlyTab
import com.example.ui.components.ChatlyTopBar
import com.example.ui.screens.ai.ChatlyAIDialog
import com.example.ui.screens.calls.CallsScreen
import com.example.ui.screens.chats.ChatListScreen
import com.example.ui.screens.communities.CommunitiesScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.search.SearchUserDialog
import com.example.ui.screens.status.StatusScreen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
  modifier: Modifier = Modifier,
  repository: DefaultChatlyRepository = DefaultChatlyRepository.instance
) {
  var currentTab by remember { mutableStateOf(ChatlyTab.CHATS) }
  var showSearchDialog by remember { mutableStateOf(false) }
  var showAIDialog by remember { mutableStateOf(false) }

  val clipboardManager = LocalClipboardManager.current
  val coroutineScope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }
  val context = LocalContext.current

  val currentUser by repository.getCurrentUser().collectAsState(initial = null)
  val chats by repository.getChats().collectAsState(initial = emptyList())
  val activeStatuses by repository.getActiveStatuses().collectAsState(initial = emptyList())
  val myStatuses by repository.getMyStatuses().collectAsState(initial = emptyList())
  val calls by repository.getCallLogs().collectAsState(initial = emptyList())

  val unreadChatsCount = chats.sumOf { it.unreadCount }

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .testTag("chatly_home_screen"),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      ChatlyTopBar(
        onSearchClick = { showSearchDialog = true },
        onAIClick = { showAIDialog = true },
        onNewGroupClick = {
          coroutineScope.launch {
            snackbarHostState.showSnackbar("Grup oluşturma sihirbazı hazır.")
          }
        },
        onNewCommunityClick = {
          currentTab = ChatlyTab.COMMUNITIES
        },
        onSettingsClick = {
          currentTab = ChatlyTab.PROFILE
        }
      )
    },
    bottomBar = {
      ChatlyBottomBar(
        selectedTab = currentTab,
        onTabSelected = { currentTab = it },
        unreadChatsCount = unreadChatsCount
      )
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      when (currentTab) {
        ChatlyTab.CHATS -> {
          ChatListScreen(
            chats = chats,
            onChatClick = { chat ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${chat.title} sohbeti seçildi.")
              }
            },
            onNewChatClick = { showSearchDialog = true },
            onSearchUserClick = { showSearchDialog = true }
          )
        }

        ChatlyTab.STATUS -> {
          StatusScreen(
            myStatuses = myStatuses,
            recentStatuses = activeStatuses,
            onAddStatusClick = {
              coroutineScope.launch {
                snackbarHostState.showSnackbar("36 saatlik Chatly Status yükleme paneli hazır.")
              }
            },
            onStatusClick = { status ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${status.userDisplayName} durumu görüntüleniyor.")
              }
            }
          )
        }

        ChatlyTab.CALLS -> {
          CallsScreen(
            calls = calls,
            onCallClick = { call ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${call.peerDisplayName} arama detayları.")
              }
            },
            onAudioCallClick = { call ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${call.peerDisplayName} sesli aranıyor...")
              }
            },
            onVideoCallClick = { call ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${call.peerDisplayName} görüntülü aranıyor...")
              }
            },
            onNewCallClick = { showSearchDialog = true }
          )
        }

        ChatlyTab.COMMUNITIES -> {
          CommunitiesScreen(
            communities = emptyList(),
            onCommunityClick = { community ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("${community.name} topluluğu açılıyor.")
              }
            },
            onNewCommunityClick = {
              coroutineScope.launch {
                snackbarHostState.showSnackbar("Yeni topluluk oluşturma paneli hazır.")
              }
            }
          )
        }

        ChatlyTab.PROFILE -> {
          currentUser?.let { user ->
            ProfileScreen(
              user = user,
              onCopyChatlyId = {
                clipboardManager.setText(AnnotatedString(user.chatlyId))
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("${user.chatlyId} kopyalandı!")
                }
              },
              onSettingsClick = { settingKey ->
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("$settingKey ayarları hazır.")
                }
              }
            )
          }
        }
      }
    }
  }

  // Dialogs
  if (showSearchDialog) {
    SearchUserDialog(
      onDismiss = { showSearchDialog = false },
      onUserSelected = { selectedUser ->
        showSearchDialog = false
        coroutineScope.launch {
          repository.sendMessage(
            chatId = "chat_${selectedUser.id}",
            message = com.example.model.ChatlyMessage(
              id = "msg_hello_${System.currentTimeMillis()}",
              chatId = "chat_${selectedUser.id}",
              senderId = currentUser?.id ?: "me",
              senderChatlyId = currentUser?.chatlyId ?: "@me",
              content = "Merhaba! Chatly üzerinden arkadaşlık isteği gönderdim."
            )
          )
          snackbarHostState.showSnackbar("${selectedUser.chatlyId} ile yeni sohbet başlatıldı.")
        }
      }
    )
  }

  if (showAIDialog) {
    ChatlyAIDialog(
      onDismiss = { showAIDialog = false },
      onToolSelected = { tool ->
        showAIDialog = false
        coroutineScope.launch {
          snackbarHostState.showSnackbar("Chatly AI: $tool aracı devrede.")
        }
      }
    )
  }
}
