package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ChatlyCyanDark
import com.example.ui.theme.ChatlyCyanSecondary
import com.example.ui.theme.ChatlyIndigoDark
import com.example.ui.theme.ChatlyIndigoPrimary

/**
 * Chatly Brand Icon: An original, modern messenger emblem.
 * Features an energetic gradient with modern rounded speech bubble geometry
 * and dual connection pulses.
 */
@Composable
fun ChatlyLogo(
  modifier: Modifier = Modifier,
  size: Dp = 72.dp,
) {
  val gradient = Brush.linearGradient(
    colors = listOf(ChatlyIndigoPrimary, ChatlyCyanSecondary),
    start = Offset.Zero,
    end = Offset.Infinite
  )

  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(size * 0.28f))
      .background(gradient)
      .testTag("chatly_logo"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(size * 0.55f)) {
      val w = this.size.width
      val h = this.size.height

      // Custom chat shape with tail
      val path = Path().apply {
        moveTo(w * 0.15f, h * 0.15f)
        lineTo(w * 0.85f, h * 0.15f)
        // Top right arc
        arcTo(
          rect = androidx.compose.ui.geometry.Rect(w * 0.7f, h * 0.15f, w * 0.85f, h * 0.35f),
          startAngleDegrees = 270f,
          sweepAngleDegrees = 90f,
          forceMoveTo = false
        )
        lineTo(w * 0.85f, h * 0.65f)
        // Bottom right arc
        arcTo(
          rect = androidx.compose.ui.geometry.Rect(w * 0.7f, h * 0.5f, w * 0.85f, h * 0.7f),
          startAngleDegrees = 0f,
          sweepAngleDegrees = 90f,
          forceMoveTo = false
        )
        lineTo(w * 0.45f, h * 0.7f)
        // Chatly speech tail
        lineTo(w * 0.25f, h * 0.95f)
        lineTo(w * 0.3f, h * 0.7f)
        lineTo(w * 0.15f, h * 0.7f)
        // Bottom left arc
        arcTo(
          rect = androidx.compose.ui.geometry.Rect(w * 0.05f, h * 0.5f, w * 0.2f, h * 0.7f),
          startAngleDegrees = 90f,
          sweepAngleDegrees = 90f,
          forceMoveTo = false
        )
        lineTo(w * 0.05f, h * 0.35f)
        // Top left arc
        arcTo(
          rect = androidx.compose.ui.geometry.Rect(w * 0.05f, h * 0.15f, w * 0.2f, h * 0.35f),
          startAngleDegrees = 180f,
          sweepAngleDegrees = 90f,
          forceMoveTo = false
        )
        close()
      }

      drawPath(path = path, color = Color.White)

      // Dual connectivity dots representing real-time communication
      drawCircle(
        color = ChatlyIndigoPrimary,
        radius = w * 0.06f,
        center = Offset(w * 0.35f, h * 0.42f)
      )
      drawCircle(
        color = ChatlyCyanSecondary,
        radius = w * 0.06f,
        center = Offset(w * 0.55f, h * 0.42f)
      )
    }
  }
}
