package com.example.ui.screens.status

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ChatlyStatus
import com.example.ui.theme.ChatlyCyanDark
import com.example.ui.theme.ChatlyCyanSecondary
import com.example.ui.theme.ChatlyIndigoPrimary

@Composable
fun StatusScreen(
  myStatuses: List<ChatlyStatus>,
  recentStatuses: List<ChatlyStatus>,
  onAddStatusClick: () -> Unit,
  onStatusClick: (ChatlyStatus) -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("status_screen")
    ) {
      // 36 Hours Chatly Status Banner
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
          )
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = Color.White
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Chatly Status — 36 SAAT",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "Durumlar tam olarak 36 saat aktif kalır, ardından otomatik olarak kaldırılır.",
                fontSize = 12.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      // "Durumum" section
      item {
        MyStatusSection(
          myStatuses = myStatuses,
          onAddStatusClick = onAddStatusClick,
          onViewMyStatus = { if (myStatuses.isNotEmpty()) onStatusClick(myStatuses.first()) }
        )
      }

      // Recent Updates Header
      item {
        PaddingHeader(title = "Son Güncellemeler")
      }

      if (recentStatuses.isEmpty()) {
        item {
          EmptyStatusPlaceholder()
        }
      } else {
        items(recentStatuses, key = { it.id }) { status ->
          StatusItemRow(
            status = status,
            onClick = { onStatusClick(status) }
          )
        }
      }
    }

    // Action buttons for Text and Camera Status
    Column(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      horizontalAlignment = Alignment.End
    ) {
      FloatingActionButton(
        onClick = onAddStatusClick,
        modifier = Modifier
          .size(46.dp)
          .testTag("add_text_status_fab"),
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.primary
      ) {
        Icon(
          imageVector = Icons.Default.Edit,
          contentDescription = "Yazılı Durum Ekle",
          modifier = Modifier.size(20.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      FloatingActionButton(
        onClick = onAddStatusClick,
        modifier = Modifier.testTag("add_camera_status_fab"),
        containerColor = MaterialTheme.colorScheme.secondary,
        contentColor = Color.White
      ) {
        Icon(
          imageVector = Icons.Default.CameraAlt,
          contentDescription = "Fotoğraf/Video Durum Ekle"
        )
      }
    }
  }
}

@Composable
private fun MyStatusSection(
  myStatuses: List<ChatlyStatus>,
  onAddStatusClick: () -> Unit,
  onViewMyStatus: () -> Unit,
) {
  val hasStatus = myStatuses.isNotEmpty()
  val statusRingBrush = Brush.sweepGradient(
    listOf(ChatlyIndigoPrimary, ChatlyCyanSecondary, ChatlyIndigoPrimary)
  )

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { if (hasStatus) onViewMyStatus() else onAddStatusClick() }
      .padding(horizontal = 16.dp, vertical = 10.dp)
      .testTag("my_status_row"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(56.dp)
        .then(
          if (hasStatus) {
            Modifier
              .clip(CircleShape)
              .border(2.5.dp, statusRingBrush, CircleShape)
              .padding(3.dp)
          } else Modifier
        )
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "BEN",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
      }

      if (!hasStatus) {
        Box(
          modifier = Modifier
            .size(20.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .align(Alignment.BottomEnd),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Ekle",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = "Durumum",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(3.dp))
      if (hasStatus) {
        val remaining = ChatlyStatus.getRemainingTimeFormatted(myStatuses.first().expiresAt)
        Text(
          text = remaining,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.secondary,
          fontWeight = FontWeight.Medium
        )
      } else {
        Text(
          text = "36 saatlik durum güncellemesi ekle",
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
private fun StatusItemRow(
  status: ChatlyStatus,
  onClick: () -> Unit
) {
  val statusRingBrush = Brush.sweepGradient(
    listOf(ChatlyIndigoPrimary, ChatlyCyanSecondary, ChatlyIndigoPrimary)
  )

  val borderModifier = if (status.isViewedByMe) {
    Modifier.border(2.5.dp, Color.Gray, CircleShape)
  } else {
    Modifier.border(2.5.dp, statusRingBrush, CircleShape)
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 10.dp)
      .testTag("status_item_${status.id}"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(54.dp)
        .clip(CircleShape)
        .then(borderModifier)
        .padding(3.dp)
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .clip(CircleShape)
          .background(Color(status.backgroundColorHex)),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = status.userDisplayName.take(1).uppercase(),
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = status.userDisplayName,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "${status.chatlyId} • ${ChatlyStatus.getRemainingTimeFormatted(status.expiresAt)}",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.secondary
      )
    }
  }
}

@Composable
private fun PaddingHeader(title: String) {
  Text(
    text = title,
    fontWeight = FontWeight.Bold,
    fontSize = 13.sp,
    color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
  )
}

@Composable
private fun EmptyStatusPlaceholder() {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
      text = "Henüz yeni durum yok",
      fontSize = 14.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "Arkadaşlarınızın paylaştığı durumlar burada 36 saat boyunca görünecektir.",
      fontSize = 12.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
      lineHeight = 16.sp
    )
  }
}
