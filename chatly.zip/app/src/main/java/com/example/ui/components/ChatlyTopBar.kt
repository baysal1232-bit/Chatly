package com.example.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatlyTopBar(
  modifier: Modifier = Modifier,
  onSearchClick: () -> Unit = {},
  onAIClick: () -> Unit = {},
  onNewGroupClick: () -> Unit = {},
  onNewCommunityClick: () -> Unit = {},
  onSettingsClick: () -> Unit = {},
) {
  var menuExpanded by remember { mutableStateOf(false) }

  TopAppBar(
    modifier = modifier.testTag("chatly_top_bar"),
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.surface,
      titleContentColor = MaterialTheme.colorScheme.primary,
    ),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        ChatlyLogo(size = 32.dp)
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "Chatly",
          fontWeight = FontWeight.ExtraBold,
          fontSize = 22.sp,
          letterSpacing = 0.5.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
    },
    actions = {
      IconButton(
        onClick = onAIClick,
        modifier = Modifier.testTag("chatly_ai_button")
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = stringResource(R.string.chatly_ai),
          tint = MaterialTheme.colorScheme.secondary
        )
      }

      IconButton(
        onClick = onSearchClick,
        modifier = Modifier.testTag("search_button")
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = stringResource(R.string.search_hint),
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      IconButton(
        onClick = { menuExpanded = true },
        modifier = Modifier.testTag("more_options_button")
      ) {
        Icon(
          imageVector = Icons.Default.MoreVert,
          contentDescription = "Seçenekler",
          tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      DropdownMenu(
        expanded = menuExpanded,
        onDismissRequest = { menuExpanded = false }
      ) {
        DropdownMenuItem(
          text = { Text(stringResource(R.string.new_group)) },
          onClick = {
            menuExpanded = false
            onNewGroupClick()
          }
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.new_community)) },
          onClick = {
            menuExpanded = false
            onNewCommunityClick()
          }
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.settings)) },
          onClick = {
            menuExpanded = false
            onSettingsClick()
          }
        )
      }
    }
  )
}
