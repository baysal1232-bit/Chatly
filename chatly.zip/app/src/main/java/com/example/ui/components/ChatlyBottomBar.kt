package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

enum class ChatlyTab(val labelRes: Int, val icon: ImageVector) {
  CHATS(R.string.tab_chats, Icons.Default.ChatBubble),
  STATUS(R.string.tab_status, Icons.Default.Schedule),
  CALLS(R.string.tab_calls, Icons.Default.Call),
  COMMUNITIES(R.string.tab_communities, Icons.Default.Groups),
  PROFILE(R.string.tab_profile, Icons.Default.Person),
}

@Composable
fun ChatlyBottomBar(
  selectedTab: ChatlyTab,
  onTabSelected: (ChatlyTab) -> Unit,
  modifier: Modifier = Modifier,
  unreadChatsCount: Int = 0,
) {
  NavigationBar(
    modifier = modifier.testTag("chatly_bottom_bar"),
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    ChatlyTab.entries.forEach { tab ->
      val isSelected = tab == selectedTab
      NavigationBarItem(
        selected = isSelected,
        onClick = { onTabSelected(tab) },
        modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MaterialTheme.colorScheme.primary,
          selectedTextColor = MaterialTheme.colorScheme.primary,
          indicatorColor = MaterialTheme.colorScheme.primaryContainer,
          unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
          unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        icon = {
          when (tab) {
            ChatlyTab.CHATS -> {
              if (unreadChatsCount > 0) {
                BadgedBox(
                  badge = {
                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                      Text("$unreadChatsCount")
                    }
                  }
                ) {
                  Icon(imageVector = tab.icon, contentDescription = stringResource(tab.labelRes))
                }
              } else {
                Icon(imageVector = tab.icon, contentDescription = stringResource(tab.labelRes))
              }
            }
            ChatlyTab.STATUS -> {
              BadgedBox(
                badge = {
                  Box(
                    modifier = Modifier
                      .clip(CircleShape)
                      .background(MaterialTheme.colorScheme.secondary)
                      .padding(horizontal = 4.dp, vertical = 1.dp)
                  ) {
                    Text(
                      text = "36s",
                      fontSize = 8.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  }
                }
              ) {
                Icon(imageVector = tab.icon, contentDescription = stringResource(tab.labelRes))
              }
            }
            else -> {
              Icon(imageVector = tab.icon, contentDescription = stringResource(tab.labelRes))
            }
          }
        },
        label = {
          Text(
            text = stringResource(tab.labelRes),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp
          )
        }
      )
    }
  }
}
