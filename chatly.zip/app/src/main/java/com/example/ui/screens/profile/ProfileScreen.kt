package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatlyUser
import com.example.ui.theme.ChatlyOnlineGreen

@Composable
fun ProfileScreen(
  user: ChatlyUser,
  onCopyChatlyId: () -> Unit,
  onSettingsClick: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var isAIEnabled by remember { mutableStateOf(true) }
  var isSecretLockEnabled by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("profile_screen")
  ) {
    // User Profile Header Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(modifier = Modifier.size(80.dp)) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = user.displayName.take(1).uppercase(),
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
              )
            }
            if (user.isOnline) {
              Box(
                modifier = Modifier
                  .size(20.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.surface)
                  .padding(3.dp)
                  .align(Alignment.BottomEnd)
              ) {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(ChatlyOnlineGreen)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = user.displayName,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            if (user.isVerified) {
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = "Doğrulanmış Hesap",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Chatly ID badge with Copy & QR affordances
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
              .clickable(onClick = onCopyChatlyId)
              .padding(horizontal = 14.dp, vertical = 6.dp)
              .testTag("copy_chatly_id_badge"),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = user.chatlyId,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = "Chatly ID Kopyala",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(14.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = user.statusMessage,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // Chatly AI Section
    item {
      SectionTitle("YAPAY ZEKÂ")
      ProfileToggleItem(
        icon = Icons.Default.AutoAwesome,
        iconTint = MaterialTheme.colorScheme.secondary,
        title = "Chatly AI",
        subtitle = "Mesaj yazma yardımcısı, çeviri ve özetleme",
        checked = isAIEnabled,
        onCheckedChange = { isAIEnabled = it }
      )
    }

    // Privacy and Security Section
    item {
      SectionTitle("GİZLİLİK VE GÜVENLİK")
      ProfileSettingItem(
        icon = Icons.Default.Lock,
        title = "Uçtan Uca Şifreleme",
        subtitle = "Mesajlarınız cihazınızda güvenle korunur",
        onClick = { onSettingsClick("encryption") }
      )
      ProfileToggleItem(
        icon = Icons.Default.Fingerprint,
        iconTint = MaterialTheme.colorScheme.primary,
        title = "Gizli Sohbet & Biyometrik Kilit",
        subtitle = "PIN veya parmak izi ile sohbetleri kilitle",
        checked = isSecretLockEnabled,
        onCheckedChange = { isSecretLockEnabled = it }
      )
      ProfileSettingItem(
        icon = Icons.Default.Timer,
        title = "Kaybolan Mesajlar",
        subtitle = "Varsayılan: Kapalı (1s, 24s, 7 gün)",
        onClick = { onSettingsClick("disappearing") }
      )
      ProfileSettingItem(
        icon = Icons.Default.Devices,
        title = "Bağlı Cihazlar",
        subtitle = "1 aktif cihaz",
        onClick = { onSettingsClick("devices") }
      )
      ProfileSettingItem(
        icon = Icons.Default.Security,
        title = "Güvenlik & İki Adımlı Doğrulama",
        subtitle = "Hesap koruma ayarları",
        onClick = { onSettingsClick("security") }
      )
    }

    // App Preferences
    item {
      SectionTitle("UYGULAMA")
      ProfileSettingItem(
        icon = Icons.Default.Notifications,
        title = "Bildirimler & Sesler",
        subtitle = "Firebase Cloud Messaging bildirim ayarları",
        onClick = { onSettingsClick("notifications") }
      )
      ProfileSettingItem(
        icon = Icons.Default.WorkspacePremium,
        iconTint = Color(0xFFEAB308),
        title = "Chatly Premium",
        subtitle = "Genişletilmiş özellikler ve premium temalar",
        onClick = { onSettingsClick("premium") }
      )
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun SectionTitle(title: String) {
  Text(
    text = title,
    fontWeight = FontWeight.Bold,
    fontSize = 12.sp,
    color = MaterialTheme.colorScheme.primary,
    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
  )
}

@Composable
private fun ProfileSettingItem(
  icon: ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit,
  iconTint: Color = MaterialTheme.colorScheme.primary,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 20.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = iconTint,
      modifier = Modifier.size(24.dp)
    )
    Spacer(modifier = Modifier.width(16.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = subtitle,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@Composable
private fun ProfileToggleItem(
  icon: ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  iconTint: Color = MaterialTheme.colorScheme.primary,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = iconTint,
      modifier = Modifier.size(24.dp)
    )
    Spacer(modifier = Modifier.width(16.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = subtitle,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = MaterialTheme.colorScheme.primary
      )
    )
  }
}
