package com.example.ui.screens.calls

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.AddIcCall
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CallDirection
import com.example.model.CallType
import com.example.model.ChatlyCall
import com.example.ui.theme.ChatlyCoralTertiary
import com.example.ui.theme.ChatlyOnlineGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallsScreen(
  calls: List<ChatlyCall>,
  onCallClick: (ChatlyCall) -> Unit,
  onAudioCallClick: (ChatlyCall) -> Unit,
  onVideoCallClick: (ChatlyCall) -> Unit,
  onNewCallClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize()) {
    if (calls.isEmpty()) {
      EmptyCallsPlaceholder(
        onNewCallClick = onNewCallClick,
        modifier = Modifier.fillMaxSize()
      )
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .testTag("calls_list")
      ) {
        items(calls, key = { it.id }) { call ->
          CallItemRow(
            call = call,
            onClick = { onCallClick(call) },
            onAudioCallClick = { onAudioCallClick(call) },
            onVideoCallClick = { onVideoCallClick(call) }
          )
        }
      }
    }

    FloatingActionButton(
      onClick = onNewCallClick,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp)
        .testTag("new_call_fab"),
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = Color.White
    ) {
      Icon(
        imageVector = Icons.Default.AddIcCall,
        contentDescription = "Yeni Arama Başlat"
      )
    }
  }
}

@Composable
private fun CallItemRow(
  call: ChatlyCall,
  onClick: () -> Unit,
  onAudioCallClick: () -> Unit,
  onVideoCallClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 12.dp)
      .testTag("call_item_${call.id}"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = call.peerDisplayName.take(1).uppercase(),
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        color = MaterialTheme.colorScheme.primary
      )
    }

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = call.peerDisplayName,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = if (call.direction == CallDirection.MISSED) ChatlyCoralTertiary else MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(3.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        val (icon, tint) = when (call.direction) {
          CallDirection.INCOMING -> Icons.AutoMirrored.Filled.CallReceived to ChatlyOnlineGreen
          CallDirection.OUTGOING -> Icons.AutoMirrored.Filled.CallMade to MaterialTheme.colorScheme.secondary
          CallDirection.MISSED -> Icons.AutoMirrored.Filled.CallMissed to ChatlyCoralTertiary
        }
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = tint,
          modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "${call.peerChatlyId} • ${formatCallDate(call.timestamp)}",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    IconButton(onClick = onAudioCallClick) {
      Icon(
        imageVector = Icons.Default.Call,
        contentDescription = "Sesli Ara",
        tint = MaterialTheme.colorScheme.primary
      )
    }

    IconButton(onClick = onVideoCallClick) {
      Icon(
        imageVector = Icons.Default.Videocam,
        contentDescription = "Görüntülü Ara",
        tint = MaterialTheme.colorScheme.secondary
      )
    }
  }
}

@Composable
private fun EmptyCallsPlaceholder(
  onNewCallClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier.padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(76.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Call,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(36.dp)
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "Henüz Arama Geçmişi Yok",
      fontSize = 19.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Birebir veya grup sesli ve görüntülü görüşmelerinizin geçmişi burada listelenir.",
      fontSize = 13.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(horizontal = 24.dp),
      lineHeight = 18.sp
    )
  }
}

private fun formatCallDate(timestamp: Long): String {
  val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
  return sdf.format(Date(timestamp))
}
